import java.sql.*;

public class MakeConnection {

	public static void main(String[] args) {

	}

	public static Connection runDB() {
		Connection con=null;
		
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url = "jdbc:mysql://localhost/twitter";
		String user = "user_board", passwd = "2501";
		con = (Connection) DriverManager.getConnection(url, user, passwd);
		System.out.println(con);
		} catch (ClassNotFoundException e1) {
			System.out.println("e1.getMessage() = " + e1.getMessage());
		} catch (SQLException e2) {
			System.out.println("e2.getMessage() = " + e2.getMessage());
		}
		return con;
		
	}
}
