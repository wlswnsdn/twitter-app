package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.helper.LoginHelper;
import com.example.myapplication.helper.TableHelper;

public class MainActivity extends AppCompatActivity {

    private TableHelper tableHelper;
    private LoginHelper loginHelper;
    private ListView listView;

    private EditText idInput;
    private EditText pwInput;

    private ILoginWithThis iLoginWithThis;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        idInput = findViewById(R.id.id_input);
        pwInput = findViewById(R.id.pw_input);


        //헬퍼들 초기화
        tableHelper = new TableHelper(this);
        loginHelper = new LoginHelper(this);
        iLoginWithThis = new ILoginWithThis();

        tableHelper.insertSampleData();
        ArrayList<String> userList = tableHelper.getUserUsernames();

        listView = findViewById(R.id.listView);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, userList);
        listView.setAdapter(adapter);

        Button loginBtn = findViewById(R.id.loginBtn);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // 로그인 버튼이 클릭되었을 때 실행되는 코드
                String id = idInput.getText().toString();
                String password = pwInput.getText().toString();

                // 여기서 데이터베이스 처리
                boolean login = loginHelper.login(id, password);
                if(login){
                    iLoginWithThis.setMyId(id);
                    Intent intent = new Intent(MainActivity.this, Home.class);
                    startActivity(intent);
                }
                else{
                    showLoginFailedToast();
                }
            }
        });

        // 'Register' 텍스트를 눌렀을 때
        TextView registerTextView = findViewById(R.id.moveToRegisterBtn);
        registerTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Home.class);
                startActivity(intent);
            }
        });





    }
    private void showLoginFailedToast() {
        Context context = getApplicationContext();
        CharSequence text = "login failed.";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }
}