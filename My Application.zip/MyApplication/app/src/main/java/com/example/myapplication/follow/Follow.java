package com.example.myapplication.follow;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

public class Follow {
	
	@SuppressWarnings({ "resource", "unused" })
    public void follow(Connection con, Statement stmt, int following_user_id, int target_user_id)
    {
		int result = check_follow(following_user_id, target_user_id, stmt);
		if(result == 0) {
			System.out.println("Can't follow yourselt");
		}
		else if(result == 1) {
			unfollow(following_user_id, target_user_id, con);
		}
		else if(result == 2) {
			following(following_user_id, target_user_id, con, stmt);
		}
		else{
			System.out.println("Error : Wrong access");
			System.exit(0);
		}	
    }
	
	public int check_follow(int following_user_id, int target_user_id, Statement stmt) {
		if (following_user_id == target_user_id) {
	        return 0;
	    } else {
	        ResultSet rs = null;
	        try {
	        	String query1 = "SELECT * FROM following WHERE target_user_id = " + target_user_id + " AND following_id = " + following_user_id;
	            rs = stmt.executeQuery(query1);
	            if (rs.next())
	                return 1;
	            else
	                return 2;
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    return -1;
	}

	
	public void following(int following_user_id, int target_user_id, Connection con, Statement stmt) {
		PreparedStatement pstmt = null;
		try {
			String query1 = "insert into following(following_id, target_user_id) values ('"+following_user_id+"','" + target_user_id + "')";
			String query2 = "insert into follower(follower_id, target_user_id) values ('"+target_user_id+"','" + following_user_id + "')";
            System.out.println("Following " + following_user_id);

            pstmt = con.prepareStatement(query1);
            pstmt.executeUpdate(query1);
            pstmt = con.prepareStatement(query2);
            pstmt.executeUpdate(query2);

		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void unfollow(int following_user_id, int target_user_id, Connection con) {
		try {
			String query1 = "delete from following where following_id =" + following_user_id;
			String query2 = "delete from follower where follower_id =" + target_user_id;
            System.out.println("Unfollow " + following_user_id);
            PreparedStatement pstmt = con.prepareStatement(query1);
            pstmt.executeUpdate(query1);
        }catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	public ArrayList<Integer> getFollower(int target_user_id, Statement stmt) {
		ResultSet followerResultSet = null;
		ArrayList<Integer> follower = new ArrayList<>(); 
		try {
			
			String sql = "select follower_id from follower where target_user_id = " + target_user_id;
			followerResultSet = stmt.executeQuery(sql);
			
			while(followerResultSet.next()) {
				int result = followerResultSet.getInt(1);
				follower.add(result);
			}
		} catch (Exception e) {
			System.out.println("no follower");
		}
		return follower;
	}
	
	public ArrayList<Integer> getFollowing(int target_user_id, Statement stmt) {
		ResultSet followingResultSet = null;
		ArrayList<Integer> following = new ArrayList<>(); 
		try {
			String sql = "select following_id from following where target_user_id = " + target_user_id;
			followingResultSet = stmt.executeQuery(sql);
			while(followingResultSet.next()) {
				int result = followingResultSet.getInt(1);
				following.add(result);
			}
		} catch (Exception e) {
			System.out.println("no following");
		}
		return following;	
	}
	
	public ArrayList<Integer> recommendFollowing(int target_user_id, Connection con) {
		ResultSet rs = null;
		ArrayList<Integer> list1 = new ArrayList();
		ArrayList<Integer> list2 = new ArrayList();
		ArrayList<Integer> result = new ArrayList();
		int std = 20;
		int cnt = 0;
		try {
			Statement stmt = con.createStatement();
			String query = "select user_id from user";
			rs = stmt.executeQuery(query);
			Statement newStmt1 = con.createStatement();
			Statement newStmt2 = con.createStatement();
			Statement newStmt3 = con.createStatement();
			
			while(rs.next()) {
				int check_id = rs.getInt(1);
				if(check_follow(check_id, target_user_id, newStmt1) == 2){
					list1 = getFollower(check_id, newStmt2);
					list2 = getFollower(target_user_id, newStmt3);
					cnt = countCommonElements(list1, list2);
				}
				if(cnt >= std) 
					result.add(check_id);
			}	
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	private int countCommonElements(ArrayList<Integer> list1, ArrayList<Integer> list2) {
        int cnt = 0;
        for (int i : list1) {
            if (list2.contains(i)) {
                cnt++;
            }
        }
        return cnt;
    }
}