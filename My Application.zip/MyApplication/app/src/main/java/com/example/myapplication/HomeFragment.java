package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private ImageView userProfileImageView;
    private RecyclerView userPosts;
    private RecyclerView recyclerView;
    private PostAdapter adapter;
    private List<PostItem> itemList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // 사용자 프로필 이미지 뷰를 찾음
        userProfileImageView = view.findViewById(R.id.user_profile_img);

        // 사용자 프로필 이미지 설정 함수 호출 (임의의 이미지 리소스를 사용하려면 R.drawable.[이미지이름]으로 변경)
        // setUserProfileImage(R.drawable.default_profile);

        // Initialize RecyclerView
        recyclerView = view.findViewById(R.id.home_posts);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));


        // Initialize data
        itemList = new ArrayList<>();
        for(int i = 0; i < 30; i++){
            itemList.add(new PostItem(R.color.black, "User " + i, "Lorem Ipsum " + i, i, i, true));
        }
        // Add more items as needed

        // Initialize adapter
        adapter = new PostAdapter(requireContext(), itemList);
        recyclerView.setAdapter(adapter);
        return view;
    }

    // 사용자 프로필 이미지 설정 함수
    private void setUserProfileImage(int drawableResource) {
        if (userProfileImageView != null) {
            userProfileImageView.setImageResource(drawableResource);
        }
    }
}
