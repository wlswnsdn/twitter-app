package com.example.myapplication;

public class PostItem {
    private int profileImageResource;
    private String userName;
    private String postContent;
    private int likeCount;
    private int commentCount;
    private Boolean isEditBtnVisible;

    public PostItem(int profileImageResource, String userName, String postContent, int likeCount, int commentCount, Boolean isEditBtnVisible) {
        this.profileImageResource = profileImageResource;
        this.userName = userName;
        this.postContent = postContent;
        this.likeCount = likeCount;
        this.commentCount = commentCount;
        this.isEditBtnVisible = isEditBtnVisible;
    }

    public int getProfileImageResource() {
        return profileImageResource;
    }

    public String getUserName() {
        return userName;
    }

    public String getPostContent() {
        return postContent;
    }

    public int getLikeCount() {
        return likeCount;
    }

    public int getCommentCount() {
        return commentCount;
    }
    public Boolean getIsEditBtnVisible() {return isEditBtnVisible; }
}
