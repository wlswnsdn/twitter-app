package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class activity_following extends AppCompatActivity {

    private RecyclerView recyclerView;
    private FollowAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_following);

        recyclerView = findViewById(R.id.following_recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<FollowItem> followingItemList = generateSampleData(); // 여기에 실제 데이터를 추가하세요.

        adapter = new FollowAdapter(followingItemList);
        recyclerView.setAdapter(adapter);

        ImageView backImageView = findViewById(R.id.back);
        backImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // '뒤로' 버튼을 클릭했을 때 현재 액티비티를 종료합니다.
                finish();
            }
        });
    }

    private List<FollowItem> generateSampleData() {
        List<FollowItem> itemList = new ArrayList<>();
        itemList.add(new FollowItem("이름1", "Lorem Ipsum is simply dummy text of the printing and typesetting industry."));
        itemList.add(new FollowItem("이름2", "Lorem Ipsum is simply dummy text of the printing and typesetting industry."));
        // 다른 아이템들도 추가할 수 있습니다.

        return itemList;
    }
}
