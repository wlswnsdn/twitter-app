package com.example.myapplication;

public class ILoginWithThis {
    private String myId="default";

    public String getMyId() {
        return myId;
    }

    public void setMyId(String myId) {
        this.myId = myId;
    }
}
