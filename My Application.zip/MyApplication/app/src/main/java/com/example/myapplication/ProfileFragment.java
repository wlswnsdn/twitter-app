package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ProfileFragment extends Fragment {

    private ImageView userProfileImage;
    private TextView userName;
    private TextView userDescription;
    private TextView userFollowing;
    private TextView userFollower;
    private RecyclerView userPosts;
    private RecyclerView recyclerView;
    private PostAdapter adapter;
    private List<PostItem> itemList;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        // Initialize views
        userProfileImage = view.findViewById(R.id.user_profile_img);
        userName = view.findViewById(R.id.user_name);
        userDescription = view.findViewById(R.id.user_description);
        userFollowing = view.findViewById(R.id.user_following);
        userFollower = view.findViewById(R.id.user_follower);
        userPosts = view.findViewById(R.id.user_posts);

        // Set user profile
        // setUserProfile()

        // Initialize RecyclerView
        recyclerView = view.findViewById(R.id.user_posts);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));


        // Initialize data
        itemList = new ArrayList<>();
        for(int i = 0; i < 30; i++){
            itemList.add(new PostItem(R.color.black, "User " + i, "Lorem Ipsum " + i, i, i, true));
        }        // Add more items as needed

        // Initialize adapter
        adapter = new PostAdapter(requireContext(), itemList);
        recyclerView.setAdapter(adapter);

        // Set click listener for '팔로잉' TextView
        userFollowing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 클릭 시 activity_following으로 이동하는 Intent 생성
                Intent intent = new Intent(requireContext(), activity_following.class);
                startActivity(intent);
            }
        });

        // Set click listener for '팔로우' TextView
        userFollower.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 클릭 시 activity_follower으로 이동하는 Intent 생성
                Intent intent = new Intent(requireContext(), Follower.class);
                startActivity(intent);
            }
        });

        return view;
    }

    private void setUserProfile(String name, String description, int profileImageResId, int followingCount, int followerCount) {
        // Set user name and description
        userName.setText(name);
        userDescription.setText(description);

        // Set user profile image
        userProfileImage.setImageResource(profileImageResId);

        // For demonstration purposes, set some dummy follower and following counts
        userFollowing.setText(followingCount + " 팔로잉");
        userFollower.setText(followerCount + " 팔로워");
    }
}
