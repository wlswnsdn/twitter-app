package com.example.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import de.hdodenhof.circleimageview.CircleImageView;

public class CommentPage extends Activity {

    private EditText commentEditText;
    private String commentText = "";
    private TextView commentTo;
    private Button replyButton;
    private ImageView cancelCommentImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comment_page);

        commentEditText = findViewById(R.id.comment_content);
        replyButton = findViewById(R.id.commentBtn);

        // CircleImageView에 이미지를 설정하는 함수 호출
        // setCircleAvatarImage();
        // 누구에게 답글 다는지 표시
        // setCommentTo("ddd");

        cancelCommentImageView = findViewById(R.id.cancel_comment);
        cancelCommentImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 클릭 이벤트가 발생했을 때 현재 액티비티 종료
                finish();
            }
        });

        // 답글 버튼 클릭 이벤트 처리
        replyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // EditText에서 텍스트 가져오기
                commentText = commentEditText.getText().toString();

                //데이터 베이스 처리

                // 화면 종료
                finish();
            }
        });
    }
    private void setCircleAvatarImage(int img) {
        CircleImageView circleImageView = findViewById(R.id.circleImageView);
        circleImageView.setImageResource(img);
    }

    private void setCommentTo(String name) {
        commentTo = findViewById(R.id.commentTo);
        commentTo.setText(name + " 님에게 보내는 답글");
    }
}
