package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Register extends AppCompatActivity {

    private EditText idInput;
    private EditText pwInput;
    private EditText nameInput;
    private EditText descriptionInput;
    private EditText emailInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        idInput = findViewById(R.id.id_input);
        pwInput = findViewById(R.id.pw_input);
        nameInput = findViewById(R.id.name_input);
        descriptionInput = findViewById(R.id.description_input);
        emailInput = findViewById(R.id.email_input);

        Button registerBtn = findViewById(R.id.registerBtn);
        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Register 버튼 클릭 시 수행되는 코드
                String id = idInput.getText().toString();
                String password = pwInput.getText().toString();
                String name = nameInput.getText().toString();
                String description = descriptionInput.getText().toString();
                String email = emailInput.getText().toString();

                // 데이터 베이스 처리
            }
        });

    }


}